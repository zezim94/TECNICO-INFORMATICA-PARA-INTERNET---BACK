<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="estilo.css">
</head>

<body>

    <h1 id="tituloPrincipal">Auto-avalição de seu perfil empreendedor</h1>
    <div class="ocultar hidden">

        <h2 id="tituloInstrucoes ">Instruções</h2>

        <div class="instrucoes ">
            <p>1. Atribua à sua pessoa uma nota de 1 a 5 para cada uma das características a seguir e escreva a nota na
                última
                coluna.</p>
            <p> 2. Some as notas obtidas para todas as características.</p>
            <p> 3. Analise seu resultado global com base nas explicações ao final.</p>
            <p> 4. Destaque seus principais pontos fortes e pontos fracos.</p>
            <p> 5. Quais dos pontos fortes destacados são mais importantes para o desempenho de suas atribuições atuais no
                seu
                trabalho?</p>
            <p> 6. Quais dos pontos fracos destacados deveriam ser trabalhados para que o seu desempenho no trabalho seja
                melhorado?
                É possível melhorá-los?</p>

        </div>
        <div class="oculto">
            <input type="submit" class="botoes" value="Iniciar">
        </div>
    </div>

    <div class="container">

        <div class="ocultacao ">


            <h2 class="titulosTabela"> Comprometimento e determinação </h2>




            <div class="tabela1">



                <table>


                    <thead>
                        <?php
                        include "tabela.php";
                        ?>
                    </thead>

                    <tbody>
                        <tr>
                            <td>1. Proatividade na tomada de decisão</td>
                            <td><input type="radio" name="1" value="5"></td>
                            <td><input type="radio" name="1" value="4"></td>
                            <td><input type="radio" name="1" value="3"></td>
                            <td><input type="radio" name="1" value="2"></td>
                            <td><input type="radio" name="1" value="1"></td>
                            <td class="nota">0</td>

                        </tr>
                        <tr>
                            <td>2. Tenacidade, obstinação</td>
                            <td><input type="radio" name="2" value="5"></td>
                            <td><input type="radio" name="2" value="4"></td>
                            <td><input type="radio" name="2" value="3"></td>
                            <td><input type="radio" name="2" value="2"></td>
                            <td><input type="radio" name="2" value="1"></td>
                            <td class="nota">0</td>

                        </tr>

                        <tr>
                            <td>3. Disciplina, dedicação</td>
                            <td><input type="radio" name="3" value="5"></td>
                            <td><input type="radio" name="3" value="4"></td>
                            <td><input type="radio" name="3" value="3"></td>
                            <td><input type="radio" name="3" value="2"></td>
                            <td><input type="radio" name="3" value="1"></td>
                            <td class="nota">0</td>

                        </tr>

                        <tr>
                            <td>4. Persistência em resolver problemas</td>
                            <td><input type="radio" name="4" value="5"></td>
                            <td><input type="radio" name="4" value="4"></td>
                            <td><input type="radio" name="4" value="3"></td>
                            <td><input type="radio" name="4" value="2"></td>
                            <td><input type="radio" name="4" value="1"></td>
                            <td class="nota">0</td>

                        </tr>

                        <tr>
                            <td>5. Disposição ao sacrifício para atingir metas</td>
                            <td><input type="radio" name="5" value="5"></td>
                            <td><input type="radio" name="5" value="4"></td>
                            <td><input type="radio" name="5" value="3"></td>
                            <td><input type="radio" name="5" value="2"></td>
                            <td><input type="radio" name="5" value="1"></td>
                            <td class="nota">0</td>

                        </tr>

                        <tr>
                            <td>6. Imersão total nas atividades que desenvolve</td>
                            <td><input type="radio" name="6" value="5"></td>
                            <td><input type="radio" name="6" value="4"></td>
                            <td><input type="radio" name="6" value="3"></td>
                            <td><input type="radio" name="6" value="2"></td>
                            <td><input type="radio" name="6" value="1"></td>
                            <td class="nota">0</td>

                        </tr>

                        <tr class="total">
                            <td colspan="6">Total</td>
                            <td>0</td>
                        </tr>

                    </tbody>
                </table>

            </div>


            <div class="oculto">
                <input type="submit" class="botoes" value="Anterior">
                <input type="submit" class="botoes" value="Próximo">
            </div>

        </div>


        <div class="tabela2 hidden">
            <h2 class="titulosTabela">Obsessão pelas oportunidades</h2>



            <table>


                <thead>
                    <?php
                    include "tabela.php";
                    ?>
                </thead>

                <tbody>
                    <tr>
                        <td>7. Procura ter conhecimento profundo das necessidades dos clientes</td>
                        <td><input type="radio" name="7" value="5"></td>
                        <td><input type="radio" name="7" value="4"></td>
                        <td><input type="radio" name="7" value="3"></td>
                        <td><input type="radio" name="7" value="2"></td>
                        <td><input type="radio" name="7" value="1"></td>
                        <td class="nota">0</td>

                    </tr>
                    <tr>
                        <td>8. É dirigido pelo mercado (market driven)</td>
                        <td><input type="radio" name="8" value="5"></td>
                        <td><input type="radio" name="8" value="4"></td>
                        <td><input type="radio" name="8" value="3"></td>
                        <td><input type="radio" name="8" value="2"></td>
                        <td><input type="radio" name="8" value="1"></td>
                        <td class="nota">0</td>

                    </tr>

                    <tr>
                        <td>9. Obsessão em criar valor e satisfazer os clientes</td>
                        <td><input type="radio" name="9" value="5"></td>
                        <td><input type="radio" name="9" value="4"></td>
                        <td><input type="radio" name="9" value="3"></td>
                        <td><input type="radio" name="9" value="2"></td>
                        <td><input type="radio" name="9" value="1"></td>
                        <td class="nota">0</td>

                    </tr>
                    <tr class="total">
                        <td colspan="6">Total</td>
                        <td>0</td>
                    </tr>

                </tbody>
            </table>

            <div class="oculto">
                <input type="submit" class="botoes" value="Anterior">
                <input type="submit" class="botoes" value="Próximo">
            </div>

        </div>

        <div class="tabela3 hidden">
            <h2 class="titulosTabela"> Tolerância ao risco, ambigüidade e incertezas </h2>

            <table>


                <thead>
                    <?php
                    include "tabela.php";
                    ?>
                </thead>

                <tbody>
                    <tr>
                        <td>10. Toma riscos calculados (analisa tudo antes de agir)</td>
                        <td><input type="radio" name="10" value="5"></td>
                        <td><input type="radio" name="10" value="4"></td>
                        <td><input type="radio" name="10" value="3"></td>
                        <td><input type="radio" name="10" value="2"></td>
                        <td><input type="radio" name="10" value="1"></td>
                        <td class="nota">0</td>

                    </tr>
                    <tr>
                        <td>11. Procura minimizar os riscos</td>
                        <td><input type="radio" name="11" value="5"></td>
                        <td><input type="radio" name="11" value="4"></td>
                        <td><input type="radio" name="11" value="3"></td>
                        <td><input type="radio" name="11" value="2"></td>
                        <td><input type="radio" name="11" value="1"></td>
                        <td class="nota">0</td>

                    </tr>

                    <tr>
                        <td>12. Tolerância às incertezas e falta de estrutura</td>
                        <td><input type="radio" name="12" value="5"></td>
                        <td><input type="radio" name="12" value="4"></td>
                        <td><input type="radio" name="12" value="3"></td>
                        <td><input type="radio" name="12" value="2"></td>
                        <td><input type="radio" name="12" value="1"></td>
                        <td class="nota">0</td>

                    </tr>

                    <tr>
                        <td>13. Tolerância ao stress e conflitos</td>
                        <td><input type="radio" name="13" value="5"></td>
                        <td><input type="radio" name="13" value="4"></td>
                        <td><input type="radio" name="13" value="3"></td>
                        <td><input type="radio" name="13" value="2"></td>
                        <td><input type="radio" name="13" value="1"></td>
                        <td class="nota">0</td>

                    </tr>

                    <tr>
                        <td>14. Hábil em resolver problemas e integrar soluções</td>
                        <td><input type="radio" name="14" value="5"></td>
                        <td><input type="radio" name="14" value="4"></td>
                        <td><input type="radio" name="14" value="3"></td>
                        <td><input type="radio" name="14" value="2"></td>
                        <td><input type="radio" name="14" value="1"></td>
                        <td class="nota">0</td>

                    </tr>

                    <tr class="total">
                        <td colspan="6">Total</td>
                        <td>0</td>
                    </tr>

            </table>
            <div class="oculto">
                <input type="submit" class="botoes" value="Anterior">
                <input type="submit" class="botoes" value="Próximo">
            </div>
        </div>

        <div class="tabela4 hidden">

            <table>

                <h2 class="titulosTabela"> Criatividade, auto-confiança e habilidade de adaptação </h2>

                <thead>
                    <?php
                    include "tabela.php";
                    ?>
                </thead>

                <tbody>
                    <tr>
                        <td>15. Não convencional, cabeça aberta, pensador</td>
                        <td><input type="radio" name="15" value="5"></td>
                        <td><input type="radio" name="15" value="4"></td>
                        <td><input type="radio" name="15" value="3"></td>
                        <td><input type="radio" name="15" value="2"></td>
                        <td><input type="radio" name="15" value="1"></td>
                        <td class="nota">0</td>

                    </tr>
                    <tr>
                        <td>16. Não se conforma com o status quo</td>
                        <td><input type="radio" name="16" value="5"></td>
                        <td><input type="radio" name="16" value="4"></td>
                        <td><input type="radio" name="16" value="3"></td>
                        <td><input type="radio" name="16" value="2"></td>
                        <td><input type="radio" name="16" value="1"></td>
                        <td class="nota">0</td>

                    </tr>

                    <tr>
                        <td>17. Hábil em adaptar a novas situações</td>
                        <td><input type="radio" name="17" value="5"></td>
                        <td><input type="radio" name="17" value="4"></td>
                        <td><input type="radio" name="17" value="3"></td>
                        <td><input type="radio" name="17" value="2"></td>
                        <td><input type="radio" name="17" value="1"></td>
                        <td class="nota">0</td>

                    </tr>

                    <tr>
                        <td>18. Não tem medo de falhar</td>
                        <td><input type="radio" name="18" value="5"></td>
                        <td><input type="radio" name="18" value="4"></td>
                        <td><input type="radio" name="18" value="3"></td>
                        <td><input type="radio" name="18" value="2"></td>
                        <td><input type="radio" name="18" value="1"></td>
                        <td class="nota">0</td>

                    </tr>

                    <tr>
                        <td>19. Hábil em definir conceitos e detalhar idéias</td>
                        <td><input type="radio" name="19" value="5"></td>
                        <td><input type="radio" name="19" value="4"></td>
                        <td><input type="radio" name="19" value="3"></td>
                        <td><input type="radio" name="19" value="2"></td>
                        <td><input type="radio" name="19" value="1"></td>
                        <td class="nota">0</td>

                    </tr>

                    <tr class="total">
                        <td colspan="6">Total</td>
                        <td>0</td>
                    </tr>

            </table>

            <div class="oculto">
                <input type="submit" class="botoes" value="Anterior">
                <input type="submit" class="botoes" value="Próximo">
            </div>


        </div>

        <div class="tabela5 hidden">

            <table>

                <h2 class="titulosTabela"> Motivação e superação </h2>

                <thead>
                    <?php
                    include "tabela.php";
                    ?>
                </thead>

                <tbody>
                    <tr>
                        <td>20. Orientação a metas e resultados</td>
                        <td><input type="radio" name="20" value="5"></td>
                        <td><input type="radio" name="20" value="4"></td>
                        <td><input type="radio" name="20" value="3"></td>
                        <td><input type="radio" name="20" value="2"></td>
                        <td><input type="radio" name="20" value="1"></td>
                        <td class="nota">0</td>

                    </tr>
                    <tr>
                        <td>21. Dirigido pela necessidade de crescer e atingir melhores resultados</td>
                        <td><input type="radio" name="21" value="5"></td>
                        <td><input type="radio" name="21" value="4"></td>
                        <td><input type="radio" name="21" value="3"></td>
                        <td><input type="radio" name="21" value="2"></td>
                        <td><input type="radio" name="21" value="1"></td>
                        <td class="nota">0</td>

                    </tr>

                    <tr>
                        <td>22. Não se preocupa com status e poder</td>
                        <td><input type="radio" name="22" value="5"></td>
                        <td><input type="radio" name="22" value="4"></td>
                        <td><input type="radio" name="22" value="3"></td>
                        <td><input type="radio" name="22" value="2"></td>
                        <td><input type="radio" name="22" value="1"></td>
                        <td class="nota">0</td>

                    </tr>

                    <tr>
                        <td>23. Autoconfiança</td>
                        <td><input type="radio" name="23" value="5"></td>
                        <td><input type="radio" name="23" value="4"></td>
                        <td><input type="radio" name="23" value="3"></td>
                        <td><input type="radio" name="23" value="2"></td>
                        <td><input type="radio" name="23" value="1"></td>
                        <td class="nota">0</td>

                    </tr>

                    <tr>
                        <td>24. Ciente de suas fraquezas e forças</td>
                        <td><input type="radio" name="24" value="5"></td>
                        <td><input type="radio" name="24" value="4"></td>
                        <td><input type="radio" name="24" value="3"></td>
                        <td><input type="radio" name="24" value="2"></td>
                        <td><input type="radio" name="24" value="1"></td>
                        <td class="nota">0</td>

                    </tr>

                    <tr>
                        <td>25. Tem senso de humor e procura estar animado</td>
                        <td><input type="radio" name="25" value="5"></td>
                        <td><input type="radio" name="25" value="4"></td>
                        <td><input type="radio" name="25" value="3"></td>
                        <td><input type="radio" name="25" value="2"></td>
                        <td><input type="radio" name="25" value="1"></td>
                        <td class="nota">0</td>

                    </tr>


                    <tr class="total">
                        <td colspan="6">Total</td>
                        <td>0</td>
                    </tr>

            </table>

            <div class="oculto">
                <input type="submit" class="botoes" value="Anterior">
                <input type="submit" class="botoes" value="Próximo">
            </div>
        </div>

        <div class="tabela6 hidden">

            <table>

                <h2 class="titulosTabela"> Liderança </h2>

                <thead>
                    <?php
                    include "tabela.php";
                    ?>
                </thead>

                <tbody>
                    <tr>
                        <td>26. Tem iniciativa</td>
                        <td><input type="radio" name="26" value="5"></td>
                        <td><input type="radio" name="26" value="4"></td>
                        <td><input type="radio" name="26" value="3"></td>
                        <td><input type="radio" name="26" value="2"></td>
                        <td><input type="radio" name="26" value="1"></td>
                        <td class="nota">0</td>

                    </tr>
                    <tr>
                        <td>27. Poder de autocontrole</td>
                        <td><input type="radio" name="27" value="5"></td>
                        <td><input type="radio" name="27" value="4"></td>
                        <td><input type="radio" name="27" value="3"></td>
                        <td><input type="radio" name="27" value="2"></td>
                        <td><input type="radio" name="27" value="1"></td>
                        <td class="nota">0</td>

                    </tr>

                    <tr>
                        <td>28. Transmite integridade e confiabilidade</td>
                        <td><input type="radio" name="28" value="5"></td>
                        <td><input type="radio" name="28" value="4"></td>
                        <td><input type="radio" name="28" value="3"></td>
                        <td><input type="radio" name="28" value="2"></td>
                        <td><input type="radio" name="28" value="1"></td>
                        <td class="nota">0</td>

                    </tr>

                    <tr>
                        <td>29. É paciente e sabe ouvir</td>
                        <td><input type="radio" name="29" value="5"></td>
                        <td><input type="radio" name="29" value="4"></td>
                        <td><input type="radio" name="29" value="3"></td>
                        <td><input type="radio" name="29" value="2"></td>
                        <td><input type="radio" name="29" value="1"></td>
                        <td class="nota">0</td>

                    </tr>

                    <tr>
                        <td>30. Sabe construir times e trabalhar em equipe
                        </td>
                        <td><input type="radio" name="30" value="5"></td>
                        <td><input type="radio" name="30" value="4"></td>
                        <td><input type="radio" name="30" value="3"></td>
                        <td><input type="radio" name="30" value="2"></td>
                        <td><input type="radio" name="30" value="1"></td>
                        <td class="nota">0</td>

                    </tr>

                    <tr class="total">
                        <td colspan="6">Total</td>
                        <td>0</td>
                    </tr>

            </table>
            <div class="oculto">
                <input type="submit" class="botoes" value="Anterior">
                <input type="submit" class="botoes" value="Próximo">
            </div>
        </div>

    </div>



    <div class="resultado hidden">

    </div>

    <script src="script.js"></script>
</body>

</html>