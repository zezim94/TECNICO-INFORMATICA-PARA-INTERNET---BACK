document.addEventListener("DOMContentLoaded", function () {

    const telaInicial = document.querySelector(".ocultar");
    const botaoIniciar = document.querySelector(".ocultar .botoes");

    const etapas = [
        ...document.querySelectorAll(".container > div"),
        document.querySelector(".resultado")
    ];

    let etapaAtual = 0;

    function esconderTodasEtapas() {
        etapas.forEach(etapa => etapa.classList.add("hidden"));
    }

    function mostrarEtapa(index) {
        esconderTodasEtapas();
        etapas[index].classList.remove("hidden");
    }

    // =========================
    // BOTÃO INICIAR
    // =========================
    botaoIniciar.addEventListener("click", function () {
        telaInicial.classList.add("hidden");
        mostrarEtapa(etapaAtual);
    });

    // =========================
    // NAVEGAÇÃO
    // =========================
    document.addEventListener("click", function (e) {

        if (e.target.classList.contains("botoes")) {

            if (e.target.value === "Próximo") {

                if (etapaAtual < etapas.length - 1) {
                    etapaAtual++;

                    if (etapaAtual === etapas.length - 1) {
                        calcularResultadoFinal();
                    }

                    mostrarEtapa(etapaAtual);
                }
            }

            if (e.target.value === "Anterior") {

                if (etapaAtual > 0) {
                    etapaAtual--;
                    mostrarEtapa(etapaAtual);
                }
            }
        }
    });

    // =========================
    // CÁLCULO DAS TABELAS
    // =========================

    function calcularTabela(tabela) {
        let total = 0;
        const linhas = tabela.querySelectorAll("tbody tr");

        linhas.forEach(linha => {
            if (!linha.classList.contains("total")) {
                const radios = linha.querySelectorAll("input[type='radio']");
                let notaCelula = linha.querySelector(".nota");
                let valorSelecionado = 0;

                radios.forEach(radio => {
                    if (radio.checked) {
                        valorSelecionado = parseInt(radio.value);
                    }
                });

                notaCelula.textContent = valorSelecionado;
                total += valorSelecionado;
            }
        });

        const totalLinha = tabela.querySelector(".total td:last-child");
        if (totalLinha) {
            totalLinha.textContent = total;
        }

        return total;
    }

    function calcularResultadoFinal() {

    let totalGeral = 0;
    let pontuacoes = [];

    const blocos = document.querySelectorAll(".container > div");

    blocos.forEach(bloco => {
        const tabela = bloco.querySelector("table");
        if (tabela) {
            let total = 0;
            const totalLinha = tabela.querySelector(".total td:last-child");
            if (totalLinha) {
                total = parseInt(totalLinha.textContent) || 0;
            }

            const titulo = bloco.querySelector(".titulosTabela").textContent;
            pontuacoes.push({ titulo, total });
            totalGeral += total;
        }
    });

    // Descobrir maior e menor pontuação
    let maior = Math.max(...pontuacoes.map(p => p.total));
    let menor = Math.min(...pontuacoes.map(p => p.total));

    let pontosFortes = pontuacoes
        .filter(p => p.total === maior)
        .map(p => p.titulo)
        .join("<br>");

    let pontosFracos = pontuacoes
        .filter(p => p.total === menor)
        .map(p => p.titulo)
        .join("<br>");

    // Classificação
    let classificacao = "";

    if (totalGeral >= 120) {
        classificacao = `
        <strong>De 120 a 150 pontos:</strong><br>
        Você provavelmente já é um empreendedor, possui as características comuns aos empreendedores e tem tudo para se diferenciar em sua organização.
        `;
    } else if (totalGeral >= 90) {
        classificacao = `
        <strong>De 90 a 119 pontos:</strong><br>
        Você possui muitas características empreendedoras e às vezes se comporta como um, porém você pode melhorar ainda mais se equilibrar os pontos ainda fracos com os pontos já fortes.
        `;
    } else if (totalGeral >= 60) {
        classificacao = `
        <strong>De 60 a 89 pontos:</strong><br>
        Você ainda não é muito empreendedor e provavelmente se comporta, na maior parte do tempo, como um administrador e não um “fazedor”. Para se diferenciar e começar a praticar atitudes empreendedoras procure analisar os seus principais pontos fracos e definir estratégias pessoais para eliminá-los.
        `;
    } else {
        classificacao = `
        <strong>Menos de 59 pontos:</strong><br>
        Você não é empreendedor e se continuar a agir como age dificilmente será um. Isto não significa que você não tem qualidades, apenas que prefere seguir a ser seguido. Se seu anseio é ser reconhecido como empreendedor, reavalie sua carreira e seus objetivos pessoais, bem como suas ações para concretizar tais objetivos.
        `;
    }

    document.querySelector(".resultado").innerHTML = `
        <h2>Resultado Final</h2>
        <p><strong>Pontuação Total:</strong> ${totalGeral} / 150</p>
        <p>${classificacao}</p>

        <hr>

        <h3>Principais pontos fortes</h3>
        <p>${pontosFortes}</p>

        <h3>Principais pontos fracos</h3>
        <p>${pontosFracos}</p>

        <hr>

        <h3>Definição de estratégia a seguir</h3>
        <textarea rows="4" style="width:100%; padding:10px;"></textarea>

        <h3>Resultados desejados e prazo para alcançá-los</h3>
        <textarea rows="4" style="width:100%; padding:10px;"></textarea>

        <br><br>
        <input type="button" class="botoes" value="Anterior">
    `;
}

    // Atualiza notas automaticamente ao marcar
    const radios = document.querySelectorAll("input[type='radio']");
    radios.forEach(radio => {
        radio.addEventListener("change", function () {
            const tabela = this.closest("table");
            calcularTabela(tabela);
        });
    });

});

// tentando resolver  o titulo

const tabelas = document.querySelectorAll('.tabela2, .tabela1, .tabela3, .tabela4, .tabela5, .tabela6');

let index = 0;

function mostrarTabela(i) {
    tabelas.forEach((tabela, idx) => {
        if (idx === i) {
            tabela.classList.remove('hidden');
            // Se o título estiver separado, mostra ele também
            const titulo = tabela.previousElementSibling; 
            if (titulo && titulo.tagName === 'H2') {
                titulo.classList.remove('hidden');
            }
        } else {
            tabela.classList.add('hidden');
            const titulo = tabela.previousElementSibling;
            if (titulo && titulo.tagName === 'H2') {
                titulo.classList.add('hidden');
            }
        }
    });
}

// Inicializa a primeira tabela
mostrarTabela(index);

// Botões
document.querySelectorAll('.botoes').forEach(btn => {
    btn.addEventListener('click', (e) => {
        if (e.target.value === 'Próximo' && index < tabelas.length - 1) index++;
        if (e.target.value === 'Anterior' && index > 0) index--;
        mostrarTabela(index);
    });
});