<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Imposto de Renda</title>
</head>

<body>

    <h1>Imposto de Renda</h1>
    <form action="processa.php" method="GET">
        <label for="nome">Nome:</label>
        <input type="text" name="nome" id="nome">
        <label for="salario">Salário:</label>
        <input type="number" name="salario" id="salario">
        <input type="submit" value="Calcular">
    </form>

</body>

</html>