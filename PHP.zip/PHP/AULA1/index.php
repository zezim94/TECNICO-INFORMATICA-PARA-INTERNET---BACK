<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

    <h1>ola mundo</h1>

    <?php
    echo "<h2> <hr> ola mundo, php </h2> <br> <hr>";

    ?>

    <?= "<h3> Tag de impressão </h3> <br> <hr>" ?>

    <!-- variavel em php -->

    <?php

    $a = 31;
    $b = "Andelson";

    echo "Meu nome é {$b} e tenho {$a} anos <hr> <br>";
    echo "Meu primeiro dia hoje."

    ?>
</body>

</html>